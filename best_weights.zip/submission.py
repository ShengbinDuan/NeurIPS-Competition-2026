"""
submission.py

Current Dreyer2023 warm-up submission wrapper.

IMPORTANT FOR THIS WARM-UP:
The Codabench debug input observed on the live worker is already:
    [B, 27, 480], sfreq=120 Hz, approximately unit-scale,
which is consistent with the prepared NeuralBench-style input.

Therefore this warm-up submission does NOT apply a second:
- band-pass filter,
- notch filter,
- RobustScaler,
- per-window normalization,
- CAR.

Repeating those operations after the official/benchmark preparation would
change the distribution seen during training. Only an idempotent [-20,20]
clamp remains inside the model.

When the sealed phase changes the dataset/task contract, inspect meta and
the actual input again and retrain/rewrite the submission accordingly.
"""

from __future__ import annotations

from pathlib import Path

import torch
from torch import nn

# Keep the import path already verified on the live Track-2 worker.
from benchmark_utils.base_solver import CompetSolver


EXPECTED_CH_NAMES = [
    "Fz",
    "FCz",
    "Cz",
    "CPz",
    "Pz",
    "C1",
    "C3",
    "C5",
    "C2",
    "C4",
    "C6",
    "F4",
    "FC2",
    "FC4",
    "FC6",
    "CP2",
    "CP4",
    "CP6",
    "P4",
    "F3",
    "FC1",
    "FC3",
    "FC5",
    "CP1",
    "CP3",
    "CP5",
    "P3",
]


class EEGNetBandpower(nn.Module):
    def __init__(
        self,
        n_chans: int,
        n_classes: int,
        sfreq: float,
        dropout: float = 0.5,
    ):
        super().__init__()

        self.n_chans = int(n_chans)
        self.n_classes = int(n_classes)
        self.sfreq = float(sfreq)

        F1 = 16
        D = 2
        F2 = 32

        self.temporal = nn.Sequential(
            nn.Conv2d(
                1,
                F1,
                kernel_size=(1, 31),
                padding=(0, 15),
                bias=False,
            ),
            nn.BatchNorm2d(F1),
        )

        self.spatial = nn.Sequential(
            nn.Conv2d(
                F1,
                F1 * D,
                kernel_size=(self.n_chans, 1),
                groups=F1,
                bias=False,
            ),
            nn.BatchNorm2d(F1 * D),
            nn.ELU(),
            nn.AvgPool2d(kernel_size=(1, 4)),
            nn.Dropout(dropout),
        )

        self.separable = nn.Sequential(
            nn.Conv2d(
                F1 * D,
                F1 * D,
                kernel_size=(1, 15),
                padding=(0, 7),
                groups=F1 * D,
                bias=False,
            ),
            nn.Conv2d(
                F1 * D,
                F2,
                kernel_size=1,
                bias=False,
            ),
            nn.BatchNorm2d(F2),
            nn.ELU(),
            nn.AvgPool2d(kernel_size=(1, 8)),
            nn.Dropout(dropout),
            nn.AdaptiveAvgPool2d((1, 8)),
        )

        self.register_buffer(
            "band_edges",
            torch.tensor(
                [
                    [4.0, 8.0],
                    [8.0, 13.0],
                    [13.0, 20.0],
                    [20.0, 30.0],
                    [30.0, 45.0],
                ],
                dtype=torch.float32,
            ),
            persistent=False,
        )

        spectral_feature_dim = self.n_chans * len(self.band_edges)

        self.spec_norm = nn.LayerNorm(
            spectral_feature_dim
        )

        self.head = nn.Sequential(
            nn.Linear(
                F2 * 8 + spectral_feature_dim,
                128,
            ),
            nn.ELU(),
            nn.Dropout(dropout),
            nn.Linear(
                128,
                self.n_classes,
            ),
        )

    def _bandpower_features(
        self,
        x: torch.Tensor,
    ) -> torch.Tensor:
        n_times = x.shape[-1]

        spectrum = torch.fft.rfft(
            x,
            dim=-1,
        )

        power = (
            spectrum.real.square()
            + spectrum.imag.square()
        )

        freqs = torch.fft.rfftfreq(
            n_times,
            d=1.0 / self.sfreq,
            device=x.device,
        )

        features = []

        for band in self.band_edges:
            low = band[0]
            high = band[1]

            mask = (
                (freqs >= low)
                & (freqs < high)
            )

            band_power = (
                power[..., mask]
                .mean(dim=-1)
                .clamp_min(1e-12)
                .log()
            )

            features.append(
                band_power
            )

        return torch.stack(
            features,
            dim=-1,
        ).flatten(start_dim=1)

    def forward(
        self,
        x: torch.Tensor,
    ) -> torch.Tensor:
        if x.ndim != 3:
            raise RuntimeError(
                f"Expected [B,C,T], got {tuple(x.shape)}"
            )

        if x.shape[1] != self.n_chans:
            raise RuntimeError(
                f"Expected {self.n_chans} channels, "
                f"got {x.shape[1]}"
            )

        x = x.float()

        # Idempotent with the official clamp.
        x = x.clamp(
            -20.0,
            20.0,
        )

        temporal_features = self.temporal(
            x.unsqueeze(1)
        )

        temporal_features = self.spatial(
            temporal_features
        )

        temporal_features = self.separable(
            temporal_features
        ).flatten(start_dim=1)

        spectral_features = self.spec_norm(
            self._bandpower_features(x)
        )

        features = torch.cat(
            [
                temporal_features,
                spectral_features,
            ],
            dim=1,
        )

        return self.head(
            features
        )

    @torch.no_grad()
    def predict(
        self,
        X: torch.Tensor,
    ) -> torch.Tensor:
        logits = self(X)

        return logits.argmax(
            dim=1
        )


class Solver(CompetSolver):
    name = "Dreyer_EEGNetBandpower_official_preproc_v2"

    def load_model(
        self,
        meta,
    ):
        n_chans = int(
            meta["n_chans"]
        )
        n_times = int(
            meta["n_times"]
        )
        n_classes = int(
            meta["n_classes"]
        )
        sfreq = float(
            meta["sfreq"]
        )
        ch_names = list(
            meta.get(
                "ch_names",
                [],
            )
        )

        # This checkpoint is intentionally specific to the current warm-up.
        if n_chans != 27:
            raise RuntimeError(
                f"Expected 27 channels for Dreyer warm-up, got {n_chans}"
            )

        if n_times != 480:
            raise RuntimeError(
                f"Expected 480 samples for Dreyer warm-up, got {n_times}"
            )

        if n_classes != 2:
            raise RuntimeError(
                f"Expected 2 classes for Dreyer warm-up, got {n_classes}"
            )

        if abs(sfreq - 120.0) > 1e-6:
            raise RuntimeError(
                f"Expected sfreq=120 Hz for Dreyer warm-up, got {sfreq}"
            )

        if ch_names and ch_names != EXPECTED_CH_NAMES:
            raise RuntimeError(
                "Codabench channel order differs from the checkpoint contract.\n"
                f"Expected: {EXPECTED_CH_NAMES}\n"
                f"Got:      {ch_names}"
            )

        model = EEGNetBandpower(
            n_chans=n_chans,
            n_classes=n_classes,
            sfreq=sfreq,
        )

        # Official contract provides meta["weights_dir"].
        # Fallback keeps local smoke tests convenient.
        weights_dir = Path(
            meta.get(
                "weights_dir",
                Path(__file__).resolve().parent,
            )
        )

        weights_path = (
            weights_dir
            / "best_weights.pt"
        )

        if not weights_path.exists():
            raise FileNotFoundError(
                f"Missing checkpoint: {weights_path}"
            )

        try:
            state_dict = torch.load(
                weights_path,
                map_location="cpu",
                weights_only=True,
            )
        except TypeError:
            # Compatibility with older torch versions.
            state_dict = torch.load(
                weights_path,
                map_location="cpu",
            )

        model.load_state_dict(
            state_dict,
            strict=True,
        )

        model = model.to(
            meta["device"]
        )

        model.eval()

        return model
