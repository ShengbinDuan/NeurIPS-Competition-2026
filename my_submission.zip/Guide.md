https://www.codabench.org/competitions/17982/#/pages-tab



How to submit your model
Submission rules
Upload a fully trained model as a ZIP through the My Submissions tab. Codabench will mount the extracted files as read-only, run the model in inference mode, compute the track metric, and publish the score. It does not train your model.

Your typical my_submission.zip contains:

my_submission.zip
├── submission.py   # required: all Python inference code
├── weights.pt      # trained parameters, with any name or format
└── ...             # optional non-Python artifact like config.json
Put every file at the root of the ZIP.
submission.py must contain class Solver(CompetSolver), the model architecture, model-specific preprocessing, and all Python inference code. Additional Python modules are not supported. See below for more details.
Include every weight and optional non-Python artifact the model needs. Read them from meta["submission_dir"] in submission.py.
Nothing is installed during evaluation, so submission.py may only import what the worker image already carries — torch and the rest of the stack pinned in requirements.txt. During load_model and predict, do not train, do not download competition data, and do not write into the submission directory.

Submit in five steps
Train and validate locally with an optional NeuralBench start kit, directly through Benchopt, or with your own pipeline. Save the trained weights. If your Benchopt solver implements the optional fit and save_model methods described below, its training run writes the solver and weights into a ready-to-upload submission folder for you.

Create submission.py following the contract below.

Create the ZIP. For the example above, run:

   zip -j my_submission.zip submission.py weights.pt
   
Add config.json or any other non-Python artifact your model needs.

Check it locally first. A failed upload still costs you one of the day's submissions, and most failures are caught in seconds:

   cp my_submission/submission.py tracks/<track>/solvers/my_submission.py
   COMPET_SUBMISSION_DIR="$PWD/my_submission" \
       benchopt run tracks/<track> -d Simulated -s MyModel
   
See Test your submission locally for what this does and does not cover.

Upload. In My Submissions, select the active phase, upload the ZIP, and wait for Finished. If it fails, start with the first error in the ingestion log.

The submission.py contract
In submission.py, you write ordinary Python or PyTorch code. Benchopt provides the evaluation wrapper, but you do not need to understand its internals. Codabench expects two components:

A named class Solver(CompetSolver) implementing load_model(meta).
A model returned by load_model and exposing predict(X).
Contract 1: class Solver(CompetSolver) loads the trained model
In class Solver(CompetSolver), load_model(self, meta) -> model is required. It reconstructs the trained architecture, loads the shipped weights, moves the model to the evaluation device, and returns it in evaluation mode:

import torch

from benchmark_utils.base_solver import CompetSolver

class Solver(CompetSolver):
    name = "MyModel"

    def load_model(self, meta):
        # MyModel must be defined in this submission.py file or imported
        # from a dependency.
        model = MyModel(
            n_chans=meta["n_chans"],
            n_times=meta["n_times"],
        )
        weights = meta["submission_dir"] / "weights.pt"
        state_dict = torch.load(
            weights,
            map_location=meta["device"],
            weights_only=True,
        )
        model.load_state_dict(state_dict)
        return model.to(meta["device"]).eval()

    # Optional local-training hooks. Codabench never calls them.
    # See "Practice 2: Train and package with Benchopt" below.
    def fit(self, model, train_loader):
        ...

    def save_model(self, model, path):
        ...
Each track's solvers/ directory holds working implementations of this contract on real data — the closest reference for your own submission.py.

Remark: meta is a plain Python dictionary created and passed to load_model automatically. You do not create or upload it. It provides:

submission_dir: read-only path to the files extracted from your ZIP
device: CPU or GPU used for the model and input batches
n_chans, n_times, sfreq, ch_names, chs_info: input description
n_outputs, n_classes, or n_joints: track-specific output size
A fixed-size architecture normally uses meta["n_chans"] and meta["n_times"]. A shape-agnostic model may infer these dimensions from X.

Contract 2: The built model generates predictions
After Solver.load_model(meta) returns your model, Codabench calls that required model's predict(X) method for every evaluation batch.

X is a PyTorch tensor already on meta["device"], with shape (B, C, T):

B: batch size
C: signal channels
T: time samples
predict(X) must return the output required by the track:

Track	predict(X) must return	Output-size key	Final sealed metric
01 - EEG-to-Image	image embeddings (B, D)	meta["n_outputs"] = D	top-5 retrieval accuracy
02 - BCI Decoding	one class index per window (B,)	meta["n_classes"]	balanced accuracy
03 - Sleep Onset	seconds to sleep onset (B,) as floats	meta["n_outputs"] = 1	weighted binned MAE
04 - EMG-to-Pose	joint angles (B, n_joints, T) in degrees	meta["n_joints"]	mean angular MAE
Warm-up proxy metrics may differ. The Track description tab gives the active warm-up metric and the final sealed specification for each track.

A PyTorch model can implement predict directly:

class MyModel(torch.nn.Module):
    @torch.inference_mode()
    def predict(self, X):
        self.eval()
        return self(X)
Behind the scenes: How Codabench and Benchopt evaluate your submission
Benchopt runs each public track benchmark and computes its metrics. Codabench manages uploads, workers, and leaderboards.

Only the sealed evaluation data and labels are hidden. The submission contract remains stable, while the evaluation data and, for proxy warm-ups, the task or metric may differ by phase:

Warm-up phase	Sealed final phase
Evaluation data	development or public proxy data	held-out cohort, never released
Benchmark framework and worker image	public competition stack	same competition stack
Task and ranking metric	public proxy; see Track description	final specification; see Track description
meta keys and tensor contract	documented contract	same contract, runtime values may differ
Submission ZIP format	same contract	same contract
Tracks 01–03 currently have phase-specific proxy details. Track 04 uses the same prediction task and metric in both phases, on different evaluation data.

For portability, use only meta and the provided batches. Do not rely on undocumented dataset names, paths, subject identifiers, or fixed dimensions.