import json

import torch

from benchmark_utils.base_solver import CompetSolver

class MyModel(torch.nn.Module):

    def __init__(self, n_chans, n_times, n_classes, feature_config):
        super().__init__()

        # 配套 config.json 文件便于修改结构参数
        feature_channels = feature_config["feature_channels"]
        kernel_size = feature_config["kernel_size"]
        padding = feature_config["padding"]

        # 提取 EEG 特征，压缩时间维度
        # 输入 X 的形状是：(B, n_chans, n_times)
        # 输出 features 的形状是：(B, feature_channels[1], 1)
        self.features = torch.nn.Sequential(
            # (B, n_chans, T) -> (B, feature_channels[0], T)
            torch.nn.Conv1d(
                in_channels=n_chans,
                out_channels=feature_channels[0],
                kernel_size=kernel_size,
                padding=padding,
            ),
            torch.nn.BatchNorm1d(feature_channels[0]),
            torch.nn.ReLU(),

            # (B, feature_channels[0], T) -> (B, feature_channels[1], T)
            torch.nn.Conv1d(
                in_channels=feature_channels[0],
                out_channels=feature_channels[1],
                kernel_size=kernel_size,
                padding=padding,
            ),
            torch.nn.BatchNorm1d(feature_channels[1]),
            torch.nn.ReLU(),

            # (B, feature_channels[1], T) -> (B, feature_channels[1], 1)
            torch.nn.AdaptiveAvgPool1d(1),
        )

        # 每条 EEG 的特征 -> 各类别分数
        self.classifier = torch.nn.Linear(feature_channels[1], n_classes)

    # 前向传播
    # 完成 __init__ 中定义完的特征提取和类别评分操作
    def forward(self, X):   # X: (B, n_chans, n_times)
        features = self.features(X).squeeze(-1)  # (B, feature_channels[1])
        logits = self.classifier(features)  # (B, n_classes)
        return logits

    # 预测输出
    # 根据类别评分，选出分数最高类别
    @torch.inference_mode()
    def predict(self, X):
        return self(X).argmax(dim=1) # self 自动调用 forward，通过 argmax 取最高分数


class Solver(CompetSolver):
    name = "MyModel"

    def load_model(self, meta):
        # 从提交目录读取与权重对应的模型结构参数
        with (meta["submission_dir"] / "config.json").open(encoding="utf-8") as f:
            feature_config = json.load(f)

        # 创建所评测模型结构
        model = MyModel(
            n_chans=meta["n_chans"],
            n_times=meta["n_times"],
            n_classes=meta["n_classes"],
            feature_config=feature_config,
        )

        # 读取已保存的模型参数
        state_dict = torch.load(
            meta["submission_dir"] / "weights.pt",
            map_location=meta["device"],
            weights_only=True,
        )

        # 参数装载
        model.load_state_dict(state_dict)

        # 置入指定设备，切换评估模式，返回模型
        return model.to(meta["device"]).eval()














